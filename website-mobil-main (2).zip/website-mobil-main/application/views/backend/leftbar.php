	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">			
				<li class="ts-label">Main</li>
				<li><a href="<?php echo base_url();?>dashboard"><i class="fa fa-dashboard"></i> Dashboard</a></li>
				<!-- <li><a href="#"><i class="fa fa-exchange"></i> Sewa</a>
					<ul class="ts-sidebar-menu">
						<li><a href="sewa_bayar.php">Menunggu Pembayaran</a></li>				  						
						<li><a href="sewa_konfirmasi.php">Menunggu Konfirmasi</a></li>
						<li><a href="sewa_kembali.php">Pengembalian</a></li>
						<li><a href="sewa.php">Data Sewa</a></li>
                    </ul>
				</li> -->
				<li><a href="#"><i class="fa fa-exchange"></i> Master Data</a>
					<ul class="ts-sidebar-menu">
						<li><a href="<?php echo base_url();?>master/spek"><i class="fa fa-circle"></i> Data Spesifikasi</a></li>				  						
						<li><a href="<?php echo base_url();?>master/kategori"><i class="fa fa-circle"></i> Data Kategori</a></li>
			
                    </ul>
				</li>
				<li><a href="#"><i class="fa fa-car"></i> Mobil </a>
					<ul class="ts-sidebar-menu">			  						
						<li><a href="<?php echo base_url();?>mobil/data_mobil"><i class="fa fa-circle"></i> Data Mobil</a></li>
						<li><a href="<?php echo base_url();?>mobil/tipe_mobil"><i class="fa fa-circle"></i> Tipe Mobil</a></li>
                    </ul>
				</li>
				<li><a href="#"><i class="fa fa-car"></i> Master SPK </a>
					<ul class="ts-sidebar-menu">			  						
						<li><a href="<?php echo base_url();?>spk/data_kriteria"><i class="fa fa-circle"></i> Data Kriteria</a></li>
						<li><a href="<?php echo base_url();?>spk/data_detail_kriteria"><i class="fa fa-circle"></i> Data Detail Kriteria</a></li>
						<li><a href="<?php echo base_url();?>spk/bobot_alternatif"><i class="fa fa-circle"></i> Bobot Alternatif</a></li>
                    </ul>
				</li>
				
				<li><a href="<?php echo base_url();?>admin/profil"><i class="fa fa-gear"></i> Profil</a></li>
				<li><a href="<?php echo base_url();?>berita/data_berita"><i class="fa fa-files-o"></i> Berita</a></li>
				<!-- <li><a href="<?php echo base_url();?>admin/user"><i class="fa fa-users"></i> User</a></li> -->
				<!-- <li><a href="manage-conactusquery.php"><i class="fa fa-phone"></i> Menghubungi</a></li>
				<li><a href="manage-pages.php"><i class="fa fa-gear"></i> Kelola Halaman</a></li>
				<li><a href="update-contactinfo.php"><i class="fa fa-info"></i> Kontak Info</a></li>
				<li><a href="laporan.php"><i class="fa fa-files-o"></i> Laporan</a></li> -->
			</ul>
	</nav>