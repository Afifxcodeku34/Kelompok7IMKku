

<!--Page Header-->
<section class="page-header contactus_page">
  <div class="container">
    <div class="page-header_wrap">
      <div class="page-heading">
        <h1>Tentang Kami</h1>
      </div>
      <ul class="coustom-breadcrumb">
        <li><a href="#">Home</a></li>
        <li>Tentang Kami</li>
      </ul>
    </div>
  </div>
  <!-- Dark Overlay-->
  <div class="dark-overlay"></div>
</section>
<!-- /Page Header dfd--> 

<!--Contact-us-->
<section class="about_us section-padding">
  <div class="container">
    <div class="section-header ">
      <h2 class="text-center"> Tentang <?php   echo htmlentities($data_profil['nama_profil']); ?> ?</h2>
      <p style="text-align: justify;"><?php  echo $data_profil['deskripsi_profil']; ?> </p>
    </div>
  </div>
</section>
<!-- /Contact-us--> 

