</body>
<!-- Scripts --> 
<script src="<?php echo base_url('assets/js/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script> 
<script src="<?php echo base_url('assets/js/interface.js'); ?>"></script> 
<!--Switcher-->
<script src="<?php echo base_url('assets/switcher/js/switcher.js'); ?>"></script>
<!--bootstrap-slider-JS--> 
<script src="<?php echo base_url('assets/js/bootstrap-slider.min.js'); ?>"></script> 
<!--Slider-JS--> 
<script src="<?php echo base_url('assets/js/slick.min.js'); ?>"></script> 
<script src="<?php echo base_url('assets/js/owl.carousel.min.js'); ?>"></script>

</body>

<!-- Mirrored from themes.webmasterdriver.net/carforyou/demo/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 16 Jun 2017 07:22:11 GMT -->
</html>